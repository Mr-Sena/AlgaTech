package com.Algaworks.AlgaTech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlgaTechApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
